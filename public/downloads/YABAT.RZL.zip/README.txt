YABAT.RZL
User-facing package name on macOS, iOS, Android, Windows, and Linux.
The operating system does not run .RZL bytecode.
A TypeScript host wraps the folder. Only the host runs.
icon.png is the only click. manifest.json is REQ-0 + REQ-1.
Not Qwen. Not OpenCV.
